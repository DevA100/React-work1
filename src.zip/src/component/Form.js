import React from 'react'

const form = () => {
  return (
    <div>form</div>   
  )
}

export default form