import React from 'react'; 
import ReactDOM from 'react-dom/client';
import cssimage from './Imgs/css.png'
const cssStyles = {
    Width: '200px',
    height: '100px',
}

const Img =(
    <div>
      hello
        {/* <img src={cssimage} styles={cssStyles} alt='cssimage' /> */}
    </div>
)
const root = ReactDOM.createRoot(document.getElementById('root'))
const rootElement = document.getElementById('root')
root.render(<Img></Img>)
// import App from './component/App';

// const myFirstElement = <h1>hello react</h1>

// const root = ReactDOM.createRoot(document.getElementById('root'));
// root.render(
//     <>
//     <App/>
    
//     </>
// )
// ;

// (parameter) => {
  
// }
